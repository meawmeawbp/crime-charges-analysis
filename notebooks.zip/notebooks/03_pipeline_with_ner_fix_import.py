#ติด error

# 03_pipeline_with_ner_fix_import.py

import pandas as pd
import numpy as np
import ast
import re
from pythainlp.tag.thainer import ThaiNameTagger
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.base import TransformerMixin, BaseEstimator
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import f1_score, classification_report

# 1) Load half-split data
train_df = pd.read_csv("crime-charges-analysis/train_half.csv")
dev_df   = pd.read_csv("crime-charges-analysis/dev_half.csv")

# 2) Parse answers
def parse_answers(cell: str) -> dict:
    raw = ast.literal_eval(cell)
    out = {}
    for d in raw:
        for p, cs in d.items():
            out[p] = ast.literal_eval(cs)
    return out

train_df["parsed"] = train_df["answers"].apply(parse_answers)
dev_df["parsed"]   = dev_df["answers"].apply(parse_answers)

# 3) Prepare samples
X_train, y_train = [], []
for _, row in train_df.iterrows():
    for person, charges in row["parsed"].items():
        X_train.append(f"{person} [SEP] {row['story']}")
        y_train.append(charges)
X_dev, y_dev = [], []
for _, row in dev_df.iterrows():
    for person, charges in row["parsed"].items():
        X_dev.append(f"{person} [SEP] {row['story']}")
        y_dev.append(charges)

mlb = MultiLabelBinarizer(classes=[1,2,3,4,5,6,7])
Y_train = mlb.fit_transform(y_train)
Y_dev   = mlb.transform(y_dev)

# 4) Initialize NER via PyThaiNLP thainer tagger
ner = ThaiNameTagger()  # default uses 'thainer'
def extract_characters_ner(text: str) -> list:
    ents = ner.tag(text)  # returns list of (word, tag)
    names = [w for w,t in ents if t == "B-PERSON" or t=="I-PERSON"]
    # combine B- and I- contiguous tokens into full names
    persons, curr = [], []
    prev_tag = None
    for w,t in ents:
        if t.endswith("PERSON"):
            curr.append(w)
            prev_tag = t
        else:
            if curr:
                persons.append("".join(curr))
                curr = []
            prev_tag = None
    if curr:
        persons.append("".join(curr))
    # remove duplicates, preserve order
    seen = set(); uniq=[]
    for p in persons:
        if p not in seen:
            uniq.append(p); seen.add(p)
    return uniq

# 5) Extended lexicon (as before)
crime_keywords = {
    2: ["ขโมย","ลัก","ชิงทรัพย์","ยักยอก","แอบขโมย"],
    3: ["ประมาท","ไม่ตั้งใจ","ละเลย","ชะล่าใจ","เผลอ"],
    4: ["บุกรุก","เข้ามาโดยมิชอบ","ล้ำเขต","แอบเข้า"],
    5: ["เจตนา","ตั้งใจ","จงใจ","มุ่งประสงค์","ไตร่ตรอง","วางแผน","จงใจทำร้าย","ตั้งใจแทง","ชักปืน","วางยา"],
    6: ["ฉ้อโกง","ปลอมแปลง","หลอกลวง","แอบอ้าง","ปลอมลายเซ็น"],
    7: ["ฆ่า","สังหาร","ทำให้เสียชีวิต","วางยาพิษ","ยิงตาย"]
}

def classify_text(text: str) -> dict:
    names = extract_characters_ner(text)
    result = {n: [] for n in names}
    for sent in re.split(r"[\.\!\?]", text):
        sl = sent.lower()
        detected = {cls for cls,kws in crime_keywords.items() if any(kw in sl for kw in kws)}
        if 7 in detected:
            detected.add(5) if 5 in detected else detected.add(3)
        for n in names:
            if n in sent:
                result[n].extend(detected)
    return {n: sorted(set(v)) or [1] for n,v in result.items()}

# 6) KeywordFlag transformer
class KeywordFlag(BaseEstimator, TransformerMixin):
    def __init__(self, keywords):
        self.keywords = keywords
        self.kw_list = [kw for kws in keywords.values() for kw in kws]
    def fit(self, X, y=None): return self
    def transform(self, X):
        flags=[]
        for text in X:
            story=text.split("[SEP]")[1].lower()
            flags.append([1 if kw in story else 0 for kw in self.kw_list])
        return np.array(flags)

# 7) Build ML pipeline
feats = FeatureUnion([
    ("tfidf", TfidfVectorizer(ngram_range=(1,2), max_features=20000)),
    ("lex",   KeywordFlag(crime_keywords))
])
ml_pipe = Pipeline([
    ("features", feats),
    ("clf", OneVsRestClassifier(LogisticRegression(solver="liblinear", class_weight="balanced"), n_jobs=-1))
])
ml_pipe.fit(X_train, Y_train)

# 8) Hyperparameter tuning
param_grid={"features__tfidf__max_features":[20000,30000],"clf__estimator__C":[1,10]}
search=GridSearchCV(ml_pipe,param_grid,scoring="f1_macro",cv=3,n_jobs=-1)
search.fit(X_train,Y_train)
best=search.best_estimator_
print("Best params:",search.best_params_)

# 9) Threshold tuning
probs=best.predict_proba(X_dev)
best_thresh={}
for i,cls in enumerate([1,2,3,4,5,6,7]):
    top_f1,top_t=0,0.5
    for t in np.linspace(0.1,0.9,17):
        cur_f1=f1_score(Y_dev[:,i],(probs[:,i]>=t).astype(int))
        if cur_f1>top_f1: top_f1, top_t = cur_f1, t
    best_thresh[cls]=top_t
    print(f"Class {cls}: thr={top_t:.2f}, F1={top_f1:.3f}")

#10) Hybrid ensemble
classes_list=[1,2,3,4,5,6,7]
def classify_hybrid(text):
    rp=classify_text(text); hy={}
    for p,rc in rp.items():
        pr=best.predict_proba([f"{p} [SEP] {text}"])[0]
        mlc=[cls for i,cls in enumerate(classes_list) if pr[i]>=best_thresh[cls]] or [1]
        hy[p]=sorted(set(rc)|set(mlc)) or [1]
    return hy

#11) Evaluate
t_rows,p_rows=[],[]
for _,r in dev_df.iterrows():
    gt=parse_answers(r["answers"]); h=classify_hybrid(r["story"])
    for p,tc in gt.items():
        t_rows.append([1 if c in tc else 0 for c in classes_list])
        p_rows.append([1 if c in h.get(p,[1]) else 0 for c in classes_list])
tm,pm=np.array(t_rows),np.array(p_rows)
print("Hybrid F1 (macro):", f1_score(tm,pm,average="macro"))
print(classification_report(tm,pm,target_names=[f"Class {c}" for c in classes_list]))
