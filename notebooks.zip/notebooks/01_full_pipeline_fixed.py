# 01_full_pipeline_fixed.py

import pandas as pd
import numpy as np
import ast
import re
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.base import TransformerMixin, BaseEstimator
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import f1_score, classification_report

# Load half-split data
train_df = pd.read_csv("crime-charges-analysis/train_half.csv")
dev_df   = pd.read_csv("crime-charges-analysis/dev_half.csv")

# Parse answers column
def parse_answers(cell: str) -> dict:
    raw = ast.literal_eval(cell)
    out = {}
    for d in raw:
        for p, cs in d.items():
            out[p] = ast.literal_eval(cs)
    return out

train_df["parsed"] = train_df["answers"].apply(parse_answers)
dev_df["parsed"] = dev_df["answers"].apply(parse_answers)

# Prepare X/Y
X_train, y_train = [], []
for _, row in train_df.iterrows():
    for person, charges in row["parsed"].items():
        X_train.append(f"{person} [SEP] {row['story']}")
        y_train.append(charges)

X_dev, y_dev = [], []
for _, row in dev_df.iterrows():
    for person, charges in row["parsed"].items():
        X_dev.append(f"{person} [SEP] {row['story']}")
        y_dev.append(charges)

mlb = MultiLabelBinarizer(classes=[1,2,3,4,5,6,7])
Y_train = mlb.fit_transform(y_train)
Y_dev   = mlb.transform(y_dev)

# Rule-based classifier
crime_keywords = {
    2: ["ขโมย","ลัก","ชิงทรัพย์","ยักยอก","แอบขโมย"],
    3: ["ประมาท","ไม่ตั้งใจ","ละเลย","ชะล่าใจ","เผลอ"],
    4: ["บุกรุก","เข้ามาโดยมิชอบ","ล้ำเขต","แอบเข้า"],
    5: ["เจตนา","ตั้งใจ","จงใจ","มุ่งประสงค์","ไตร่ตรอง","วางแผน"],
    6: ["ฉ้อโกง","ปลอมแปลง","หลอกลวง","แอบอ้าง","ปลอมลายเซ็น"],
    7: ["ฆ่า","สังหาร","ทำให้เสียชีวิต","วางยาพิษ","ยิงตาย"]
}

def extract_characters_regex(text: str) -> list:
    tokens = re.findall(r"[ก-๙]{2,}", text)
    return list(set(tokens))

def classify_text(text: str) -> dict:
    names = extract_characters_regex(text)
    result = {n: [] for n in names}
    for sent in re.split(r"[\.\!\?]", text):
        sl = sent.lower()
        detected = {cls for cls, kws in crime_keywords.items() if any(kw in sl for kw in kws)}
        if 7 in detected:
            if 5 in detected: detected.add(5)
            elif 3 in detected: detected.add(3)
        for n in names:
            if n in sent:
                result[n].extend(detected)
    return {n: sorted(set(v)) or [1] for n, v in result.items()}

# KeywordFlag for lexicon features
class KeywordFlag(BaseEstimator, TransformerMixin):
    def __init__(self, keywords):
        self.keywords = keywords            # ensure cloneable param
        self.kw_list = [kw for kws in keywords.values() for kw in kws]
    def fit(self, X, y=None):
        return self
    def transform(self, X):
        flags = []
        for text in X:
            story = text.split("[SEP]")[1].lower()
            flags.append([1 if kw in story else 0 for kw in self.kw_list])
        return np.array(flags)

# Build ML pipeline
lex_feat = FeatureUnion([
    ("tfidf", TfidfVectorizer(ngram_range=(1,2), max_features=20000)),
    ("lex",   KeywordFlag(crime_keywords))
])

pipeline = Pipeline([
    ("features", lex_feat),
    ("clf",      OneVsRestClassifier(LogisticRegression(solver="liblinear", class_weight="balanced"), n_jobs=-1))
])

pipeline.fit(X_train, Y_train)

# Hyperparameter tuning
param_grid = {
    "features__tfidf__max_features": [10000, 20000, 30000],
    "clf__estimator__C": [0.1, 1, 10]
}
search = GridSearchCV(pipeline, param_grid, scoring="f1_macro", cv=3, n_jobs=-1)
search.fit(X_train, Y_train)
pipeline_best = search.best_estimator_
print("Best params:", search.best_params_)

# Threshold tuning
probs = pipeline_best.predict_proba(X_dev)
best_thresh = {}
for i, cls in enumerate([1,2,3,4,5,6,7]):
    best_f1, best_t = 0, 0.5
    for t in np.linspace(0.1, 0.9, 17):
        y_t = (probs[:, i] >= t).astype(int)
        f1 = f1_score(Y_dev[:, i], y_t)
        if f1 > best_f1:
            best_f1, best_t = f1, t
    best_thresh[cls] = best_t
    print(f"Class {cls}: thresh={best_t:.2f}, F1={best_f1:.3f}")

# Hybrid ensemble
classes_list = [1,2,3,4,5,6,7]
def classify_hybrid(text: str) -> dict:
    rule_pred = classify_text(text)
    hybrid = {}
    for person, rule_charges in rule_pred.items():
        sample = f"{person} [SEP] {text}"
        probs = pipeline_best.predict_proba([sample])[0]
        ml_charges = [cls for i, cls in enumerate(classes_list) if probs[i] >= best_thresh[cls]] or [1]
        combined = sorted(set(rule_charges) | set(ml_charges))
        hybrid[person] = combined or [1]
    return hybrid

# Evaluate hybrid
true_rows, pred_rows = [], []
for _, row in dev_df.iterrows():
    gt = parse_answers(row["answers"])
    hy = classify_hybrid(row["story"])
    for person, true_charges in gt.items():
        true_rows.append([1 if cls in true_charges else 0 for cls in classes_list])
        pred_rows.append([1 if cls in hy.get(person, [1]) else 0 for cls in classes_list])

true_mat = np.array(true_rows)
pred_mat = np.array(pred_rows)

print("Hybrid F1 (macro):", f1_score(true_mat, pred_mat, average="macro"))
print(classification_report(true_mat, pred_mat, target_names=[f"Class {c}" for c in classes_list]))
