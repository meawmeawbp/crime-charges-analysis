import pandas as pd

# Load the uploaded CSV file
file_path = r"C:\Users\ASUS\Downloads\rag151-300.csv"
data = pd.read_csv(file_path)

# Show the first few rows of the data to understand its structure
data.head()
