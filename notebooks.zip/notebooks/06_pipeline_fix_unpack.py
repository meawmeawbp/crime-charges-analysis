# 06_pipeline_fix_unpack.py

#0.051

import pandas as pd
import numpy as np
import ast
import re
from pythainlp.tag.thainer import ThaiNameTagger
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.base import TransformerMixin, BaseEstimator
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import f1_score, classification_report

# Load half-split data
train_df = pd.read_csv("crime-charges-analysis/train_half.csv")
dev_df   = pd.read_csv("crime-charges-analysis/dev_half.csv")

# Parse answers
def parse_answers(cell: str) -> dict:
    raw = ast.literal_eval(cell)
    out = {}
    for d in raw:
        for p, cs in d.items():
            out[p] = ast.literal_eval(cs)
    return out

train_df["parsed"] = train_df["answers"].apply(parse_answers)
dev_df["parsed"]   = dev_df["answers"].apply(parse_answers)

# Prepare data
X_train, y_train = [], []
for _, row in train_df.iterrows():
    for person, charges in row["parsed"].items():
        X_train.append(f"{person} [SEP] {row['story']}")
        y_train.append(charges)
X_dev, y_dev = [], []
for _, row in dev_df.iterrows():
    for person, charges in row["parsed"].items():
        X_dev.append(f"{person} [SEP] {row['story']}")
        y_dev.append(charges)

mlb = MultiLabelBinarizer(classes=[1,2,3,4,5,6,7])
Y_train = mlb.fit_transform(y_train)
Y_dev   = mlb.transform(y_dev)

# Initialize NER
ner = ThaiNameTagger()  # default 'thainer'
def extract_characters_ner(text: str) -> list:
    ents = ner.get_ner(text)  # each ent may be (word, tag, ...)
    persons, curr = [], []
    for ent in ents:
        word = ent[0]
        tag  = ent[1]
        if tag.endswith("PERSON"):
            curr.append(word)
        else:
            if curr:
                persons.append("".join(curr))
                curr = []
    if curr:
        persons.append("".join(curr))
    # unique preserve order
    seen = set(); unique = []
    for p in persons:
        if p not in seen:
            unique.append(p); seen.add(p)
    return unique

# Extended lexicon
crime_keywords = {
    2: ["ขโมย","ลัก","ชิงทรัพย์","ยักยอก","แอบขโมย"],
    3: ["ประมาท","ไม่ตั้งใจ","ละเลย","ชะล่าใจ","เผลอ"],
    4: ["บุกรุก","เข้ามาโดยมิชอบ","ล้ำเขต","แอบเข้า"],
    5: ["เจตนา","ตั้งใจ","จงใจ","มุ่งประสงค์","ไตร่ตรอง","วางแผน","จงใจทำร้าย","ตั้งใจแทง","ชักปืน","วางยา"],
    6: ["ฉ้อโกง","ปลอมแปลง","หลอกลวง","แอบอ้าง","ปลอมลายเซ็น"],
    7: ["ฆ่า","สังหาร","ทำให้เสียชีวิต","วางยาพิษ","ยิงตาย"]
}

def classify_text(text: str) -> dict:
    names = extract_characters_ner(text)
    result = {n: [] for n in names}
    for sent in re.split(r"[\.\!\?]", text):
        sl = sent.lower()
        detected = {cls for cls,kws in crime_keywords.items() if any(kw in sl for kw in kws)}
        if 7 in detected:
            detected.add(5) if 5 in detected else detected.add(3)
        for n in names:
            if n in sent:
                result[n].extend(detected)
    return {n: sorted(set(v)) or [1] for n,v in result.items()}

# KeywordFlag
class KeywordFlag(BaseEstimator, TransformerMixin):
    def __init__(self, keywords):
        self.keywords = keywords
        self.kw_list = [kw for kws in keywords.values() for kw in kws]
    def fit(self, X, y=None): return self
    def transform(self, X):
        flags=[]
        for text in X:
            story = text.split("[SEP]")[1].lower()
            flags.append([1 if kw in story else 0 for kw in self.kw_list])
        return np.array(flags)

# Build and train ML pipeline
feats = FeatureUnion([
    ("tfidf", TfidfVectorizer(ngram_range=(1,2), max_features=20000)),
    ("lex",   KeywordFlag(crime_keywords))
])
ml_pipe = Pipeline([
    ("features", feats),
    ("clf", OneVsRestClassifier(LogisticRegression(solver="liblinear", class_weight="balanced"), n_jobs=-1))
])
ml_pipe.fit(X_train, Y_train)

# Hyperparameter tuning
param_grid={"features__tfidf__max_features":[20000,30000],"clf__estimator__C":[1,10]}
search = GridSearchCV(ml_pipe, param_grid, scoring="f1_macro", cv=3, n_jobs=-1)
search.fit(X_train, Y_train)
best = search.best_estimator_
print("Best params:", search.best_params_)

# Threshold tuning
probs = best.predict_proba(X_dev)
best_thresh = {}
for i, cls in enumerate([1,2,3,4,5,6,7]):
    top_f1, top_t = 0, 0.5
    for t in np.linspace(0.1,0.9,17):
        f = f1_score(Y_dev[:,i], (probs[:,i]>=t).astype(int))
        if f > top_f1: top_f1, top_t = f, t
    best_thresh[cls] = top_t
    print(f"Class {cls}: thr={top_t:.2f}, F1={top_f1:.3f}")

# Hybrid classifier
classes_list=[1,2,3,4,5,6,7]
def classify_hybrid(text: str) -> dict:
    rule_pred = classify_text(text)
    hybrid = {}
    for person, rc in rule_pred.items():
        pr = best.predict_proba([f"{person} [SEP] {text}"])[0]
        mlc = [cls for i,cls in enumerate(classes_list) if pr[i]>=best_thresh[cls]] or [1]
        hybrid[person] = sorted(set(rc) | set(mlc)) or [1]
    return hybrid

# Evaluate hybrid
true_rows, pred_rows = [], []
for _, r in dev_df.iterrows():
    gt = parse_answers(r["answers"])
    hy = classify_hybrid(r["story"])
    for p, tc in gt.items():
        true_rows.append([1 if c in tc else 0 for c in classes_list])
        pred_rows.append([1 if c in hy.get(p,[1]) else 0 for c in classes_list])
true_mat, pred_mat = np.array(true_rows), np.array(pred_rows)
print("Hybrid F1 (macro):", f1_score(true_mat, pred_mat, average="macro"))
print(classification_report(true_mat, pred_mat, target_names=[f"Class {c}" for c in classes_list]))
