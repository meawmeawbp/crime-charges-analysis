import matplotlib.pyplot as plt

# ข้อมูล
classes = ['2: ลักทรัพย์/ชิงทรัพย์', '3: ความผิดพิเศษ', '5: ชีวิต/ร่างกาย', '6: ฉ้อโกง', '7: ฆ่า/ทำร้ายถึงตาย']
counts = [48070, 10476, 16678, 8639, 1618]

# กราฟเส้นจำนวนคดีแต่ละคลาส
plt.figure(figsize=(10,5))
plt.plot(classes, counts, marker='o')
plt.title('จำนวนคดีจับกุมตามคลาสประเภทความผิด (ปี 2565-2566)')
plt.ylabel('จำนวนคดี (จับกุม)')
plt.grid(True)
plt.show()

# กราฟแท่งค่าเฉลี่ยคลาส 2-7
average = sum(counts) / len(counts)
plt.figure(figsize=(6,4))
plt.bar(['ค่าเฉลี่ยคลาส 2-7'], [average], color='orange')
plt.ylabel('จำนวนคดีเฉลี่ย (จับกุม)')
plt.title('ค่าเฉลี่ยจำนวนคดีจับกุมต่อคลาส (2-7)')
plt.show()
